# Mycorrhiza

<metadata>
Post Name: Theory of Change - Agent Based Models for Collective Intelligence
Slug: toc-mycorrhiza
Authors: Jonas Hallgren, Markov Grey, Aaron Halpern
Tags: simulation, collective-intelligence, complexity
Date: 2025-05-09
Description: Exploring how agent-based models can help understand emergent behaviors in AI governance systems and complex networks.
Image: header.jpg
</metadata>

**AI governance needs to understand emergent behaviors that arise from interactions between systems rather than individual AI properties.** AIs don't exist in isolation. They form interconnected networks with other complex systems  like politics, economics, or supply chains that create risks invisible when studying AI models alone. These interconnected complex systems have self-reinforcing dynamics that persist regardless of which specific agents execute them. They are in a sense “agent-agnostic”, because it is a process that potentially leads to gradual human disempowerment even without any individual agent (human or AI) being malicious or misaligned ([Critch & Russel, 2023](https://arxiv.org/abs/2306.06924); [Critch, 2021](https://www.alignmentforum.org/posts/LpM3EAakwYdS6aRKf/what-multipolar-failure-looks-like-and-robust-agent-agnostic)). Current AI governance approaches analyze individual AI systems for risks, safety and alignment but miss the collective dynamics that emerge when systems interact. Think about how studying a single tree wouldn't tell you about how resilient the entire forest is. In the same way analyzing AI systems in isolation misses critical systemic risks.

**Nature's Solution: Mycorrhizal Networks to enable resilience and intelligence across a distributed system.** In biological ecosystems, mycorrhizal networks are roots of fungal networks that create vast underground connections between trees. These roots transform individual trees into a collectively intelligent ecosystem where information and nutrients flow between plants. When resources are scarce in one area, nutrients flow through the root network from abundance to scarcity. When pathogens attack one tree, chemical warning signals spread through the roots of the forest network, allowing other trees to preemptively activate defenses. The forest's resilience and safety properties emerge from the processes flowing through these connections, not from the properties of any single agent.

[](https://lh7-rt.googleusercontent.com/docsz/AD_4nXf0Vz7TT3s_zLxbhuqdT7051KrFtkqx6jxh2o_4PNzHWiIi1g5pMVnQWOvaGJQHC_M6tIrNUKdNWT0W69zCg5kokbgCcmfhOUzKOAHw-6aFFms5aIJkWoJtQeP3r-xsWTBfrP22?key=AG7uiwgHaoRVCNVU9Hh_syrH)

<figure-caption>

Natures Mycorrhizal Networks

</figure-caption>

Inspired by this, we want to create **The Mycorrhiza Simulation Framework** - A form of collective intelligence for AI governance by fundamentally shifting how we model complex systems.

## **The Mycorrhiza Simulation Framework**

**What is Mycorrhiza?** Mycorrhiza is our complex systems modeling approach that captures emergent behaviors in networks of interacting AI systems. Just as mycorrhizal networks in forests connect trees through fungal filaments to share resources and information, our framework models the connections between AI systems and how these connections transform over time. Traditional AI research focuses on individual systems, but Mycorrhiza zooms out to examine the collective behavior that emerges when multiple systems interact, allowing us to anticipate emergent risks and design better governance approaches.

[](https://lh7-rt.googleusercontent.com/docsz/AD_4nXfTsHUO8rHWI0d5sGmWP-XbMnUrgqQQnSrO9g975d2MIbWjtC32YbrYUerOO50pgYNh0vY42_WtqWwLxjJH3zK0pzv_6SxWrYYbobfW9pazB-xaycnHw-Um5oPIh_hEd7HGO5k07w?key=AG7uiwgHaoRVCNVU9Hh_syrH)

<figure-caption>

Our Mycorrhizal Networks

</figure-caption>

**Traditional agent-based models are insufficient because they focus on individual properties rather than system transformations.** These approaches track agent states and behaviors at each timestep but struggle to capture gradual shifts in control and influence. Multi-agent simulations face similar limitations. While they can model interactions between agents, they typically assume fixed rules of interaction that don't evolve over time. Real governance challenges involve shifting power dynamics, evolving information asymmetries, and changing decision rights—transformative processes that occur between agents rather than within them. Existing multiagent modelling approaches also struggle with bidirectional causality, where micro-level interactions produce macro-level patterns that then constrain future micro-level behaviors. These limitations make it nearly impossible to track how control and influence flow through complex systems over time.

**Our proposed simulation framework shifts focus from agents to processes, modeling how systems transform each other over time.** Our approach instead treats governance mechanisms as explicit transformations of multi-agent systems that can be formally analyzed, composed, and verified. Instead of asking "what will each AI system do?", we ask "how will influence, information, and control transform as they flow through networks of interacting systems?" We identify core transformative processes like information diffusion (how knowledge spreads), delegation (how decision rights transfer between humans and AI), and influence shifts (how power redistributes). By modeling governance mechanisms as transformations that interact with existing system dynamics, we could systematically evaluate how different approaches might preserve human control under various conditions.

**The process-centric view can track and simulate cascading effects, and subtle accumulating changes that might gradually erode human control.** As examples of concrete risks that we can mitigate, the proposed framework can identify feedback loops where initial delegation patterns accelerate further delegation leading to the risk of gradual disempowerment ([Kulveit et al., 2025](https://arxiv.org/abs/2501.16946)), or we can model how information asymmetries develop when AI systems have privileged access to data humans cannot verify leading to various multi agent AI risks ([Hammond et al., 2025](https://arxiv.org/abs/2502.14143)).

## **Tractability and Complexity**

**While complete prediction of chaotic complex systems is impossible, identifying critical patterns and transition points is both tractable and valuable.** Like all complex systems modeling, we face fundamental computational and epistemic constraints. Meteorologists can't reliably predict whether it will rain in San Francisco three weeks from today—the chaotic nature of weather systems makes precise long-term predictions impossible. In the same way, we cannot claim to precisely forecast the state of AI governance systems years in advance. But at the same time, we also know that climate scientists can confidently predict phenomena like El Niño, long-term warming trends, or the fact that we have a critical warming threshold of 1.5 degrees that we must stay under. Similarly, we focus on identifying robust patterns, critical thresholds, and phase transitions—more like climate modeling than weather forecasting. This means that like climate scientists map climate stability boundaries, we can map the stability boundaries of human-AI systems and identify conditions, and interventions that make desired outcomes more likely.

For example, we might discover that human control remains robust until AI systems occupy more than 60% of key information-processing roles, but rapidly diminishes beyond that threshold. Or we might find that certain levels of delegation to AI remain reversible until they create self-reinforcing feedback loops, after which they become effectively locked in.

**Focusing on processes rather than agents makes our framework invariant to paradigm changes.** Instead of designing simulations and risk forecasts around specific agent capabilities, model architectures, or deployment models, etc. that will quickly become obsolete, we would identify fundamental system properties that must be preserved regardless of underlying agent or company specific implementation details. This approach would remain relevant even as AI capabilities grow and new systems emerge with different behaviors but similar systemic effects. This methodical approach to governance design draws inspiration from robust control theory in engineering, where systems are designed to maintain stability even when operating conditions deviate significantly from the expected. Just as engineers design aircraft to remain stable even in turbulence or with partial system failures, we design governance mechanisms to maintain human control even as AI capabilities advance in unexpected ways or when parts of the governance system itself fail.

## **Examples of Real-World Applications**

**The 2008 financial crisis demonstrates how interconnected systems can produce catastrophic failures invisible to traditional risk models.** Regulators and financial institutions focused on individual banks' risk exposures while missing how these risks propagated through the broader system. Models treated mortgage defaults as independent events rather than recognizing how they could trigger cascading failures across interconnected financial institutions ([Bookstaber, 2017](https://www.jstor.org/stable/j.ctvc776sc)). A Mycorrhiza-like framework could have identified critical thresholds where seemingly benign individual behaviors—like writing mortgages with minimal documentation—produced dangerous system-wide vulnerabilities. By modeling how processes like information asymmetries, leverage accumulation, and risk transference transformed the financial system, regulators might have recognized early warning signs and implemented circuit-breaker mechanisms before the system reached irreversible failure states.

**We transform AI governance from a reactive intuition-based approach to a proactive  evidence-based approach.** Just as computational fluid dynamics revolutionized aircraft design—moving from educated guesses to systematically tested designs—our framework helps policymakers test governance proposals against complex system dynamics before implementation. This enables anticipatory governance rather than reactive responses, helping stakeholders identify potential failures before they manifest in deployed systems.

As concrete examples, the Mycorrhiza framework could translate these governance challenges into concrete, testable scenarios:

- **Intellectual Property in AI Systems:** When stakeholders identify challenges around AI systems and intellectual property rights, our simulations can test various attribution mechanisms, showing how they affect creator compensation throughout the ecosystem. We can identify whether enforcement mechanisms remain effective when AI systems interact strategically and discover whether certain policies inadvertently concentrate power among the largest AI providers.
- **Alignment Standards Development:** For stakeholders working on standards to ensure AI systems remain aligned with human values, our framework tests whether proposed standards create perverse incentives when multiple AI systems interact. We can identify potential "race to the bottom" dynamics where competition undermines safety practices and develop verification mechanisms that remain robust even as systems become more complex.
- **Compute Governance:** When stakeholders propose policies governing access to computational resources, our simulations reveal how different allocation mechanisms affect innovation across diverse organizations. We can identify whether seemingly fair processes might lead to unexpected power consolidation and help develop adaptive governance mechanisms that respond to emerging strategic behaviors.

## **Validation & Verification**

**This simulation work directly connects to our mathematical foundations research.** While our simulations provide intuitive visualization of system dynamics, they are grounded in rigorous mathematical models that capture information flows, incentive structures, and coordination mechanisms within complex networks. This mathematical foundation ensures our simulations accurately represent real-world dynamics and allows us to formally analyze the properties of different governance approaches.

## **Success Metrics**

**The measure of success isn't better simulations – it's governance systems that demonstrably preserve human agency as AI capabilities grow.** Our simulation framework is simply a means to an end: governance mechanisms that ensure technological progress empowers humans across diverse futures. We evaluate our framework's utility by its ability to:

1. Identify critical thresholds where governance interventions would be most effective
2. Predict unintended consequences of proposed policies before implementation
3. Design interventions that maintain important properties like meaningful human control and fair resource distribution even as AI systems evolve.

This framework represents a fundamental shift in how we approach AI governance—from studying individual trees to understanding the forest as a living, interconnected system.